# Spec: [Feature Name]

> Template — copy this per feature/sprint. Keep old specs, don't overwrite.
> Last updated: [DATE]

---

## 🎯 Goal

> Write 1–3 sentences. What does this do and why does it matter?
> You do NOT need to know the exact implementation — just the goal.

[Sol writes here]

---

## 🤖 AI-Generated Spec Draft

> Claude Code fills this in after reading the Goal above.
> Sol then reviews and marks each item.

### User Stories
- As a [user], I want to [action] so that [outcome]

### Functional Requirements
1.
2.
3.

### Out of Scope (this sprint)
-

### Open Questions
-

---

## ✅ Sol's Approval

> Sol marks each section after reviewing the AI draft

| Item | Status | Notes |
|------|--------|-------|
| User stories | ☐ Approved / ☐ Needs change | |
| Functional requirements | ☐ Approved / ☐ Needs change | |
| Out of scope | ☐ Approved / ☐ Needs change | |

**Overall:** ☐ Approved to build / ☐ Revise first

---

## 🔗 References

- Related files:
- Related decisions in log:

# Decision Log

> All significant technical and UX decisions go here.
> Claude Code and Codex should both read AND update this file.
> Most recent entries at the top.

---

## How to Add an Entry

```
| YYYY-MM-DD | What was decided | Why this approach was chosen | Who decided |
```

"Who decided" = Claude Code / Codex / Sol

---

## Log

| Date | Decision | Rationale | Decided By |
|------|----------|-----------|------------|
| | | | |

---

## Deprecated Decisions

> Decisions that were reversed — keep for reference

| Date | Original Decision | Why Reversed | New Decision |
|------|------------------|--------------|--------------|
| | | | |
